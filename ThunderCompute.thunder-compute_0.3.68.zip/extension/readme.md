# Access Cheap Cloud GPUs Locally - Thunder Compute

Access cloud GPUs in one click directly from VS Code. Startups, researchers, and data scientists, can prototype AI/ML on the cheapest NVIDIA A100s, H100s, and T4s directly through the IDE.

## Features

- **One-Click Connect**: Connect to your instances in one click, without SSH keys or config
- **Instance Management**: View, stop, start, and delete your Thunder Compute instances from a dedicated sidebar
- **Create Instances**: Create new instances with custom configurations
- **Local File Access**: Drag files into VSCode to instantly transfer them to your instance

## Getting Started

1. Install the extension from the VS Code Marketplace
2. Click the Thunder Compute (lightning bolt) icon in the activity bar
3. Press F1 and use the "Thunder Compute: Login" command to authenticate with your API token
   - If you don't have an API token, use "Thunder Compute: Get API Token" to open the Thunder Compute console
4. Create a new instance or connect to an existing one

View our [Documentation](https://www.thundercompute.com/docs/quickstart) for detailed setup instructions.

## Requirements

- VS Code 1.80.0 or higher
- An active Thunder Compute account (sign up at [Thunder Compute](https://www.thundercompute.com))
- Remote - SSH extension installed for connecting to instances

## Commands

- `Thunder Compute: Login` - Login to your Thunder Compute account
- `Thunder Compute: Logout` - Logout from your Thunder Compute account
- `Thunder Compute: Get API Token` - Open the Thunder Compute console to create an API token
- `Thunder Compute: Create Instance` - Create a new Thunder Compute instance
- `Thunder Compute: Start Instance` - Start a stopped instance
- `Thunder Compute: Stop Instance` - Stop a running instance
- `Thunder Compute: Delete Instance` - Delete an instance
- `Thunder Compute: Connect to Instance` - Connect to a running instance without config (automatically manages SSH connection)
- `Thunder Compute: Refresh Instances` - Refresh the instance list

## About Thunder Compute

Thunder Compute provides easy access to powerful GPU resources in the cloud. Perfect for machine learning, data science, and AI development.

Visit [Thunder Compute](https://www.thundercompute.com) to learn more or sign up for an account.
See [Pricing](https://www.thundercompute.com/pricing) for up-to-date hourly rates. No contracts or commitments.
